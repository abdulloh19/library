create function return_author_id_avg_price(a_id integer)
    returns TABLE(author_name character varying, avg_price numeric)
    language plpgsql
as
$$
begin
    return query
    select a.full_name, round(avg(price)) as ortacha_narx
    from authors a
             join books b on a.id = b.author_id
    where a.id = a_id
    group by a.full_name;
end;
$$;

alter function return_author_id_avg_price(integer) owner to postgres;

