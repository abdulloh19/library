create function factorial(n integer) returns numeric
    language plpgsql
as
$$
declare
    v_result numeric := 1;
    i        int;
begin
    if n < 0 then
        raise exception 'Manfiy sonlar uchun faktorial mavjud emas!';
    end if;

    for i in 1..n
        loop
            v_result = v_result * i;
        end loop;
return v_result;
end;
$$;

alter function factorial(integer) owner to postgres;

