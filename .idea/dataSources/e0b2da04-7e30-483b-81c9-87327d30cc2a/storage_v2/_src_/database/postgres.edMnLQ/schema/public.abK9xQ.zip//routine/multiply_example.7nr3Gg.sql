create function multiply_example(a integer, b integer) returns integer
    language plpgsql
as
$$
begin
    return a * b;
end;
$$;

alter function multiply_example(integer, integer) owner to postgres;

