create procedure delete_stock_min()
    language plpgsql
as
$$
begin
    delete from books where stock = (select min(stock) from books);
end;
$$;

alter procedure delete_stock_min() owner to postgres;

