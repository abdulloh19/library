create function get_book_all_count(countrys character varying)
    returns TABLE(author_name character varying, books_count integer)
    language plpgsql
as
$$
declare
    total_books int;
begin
    return query
        select a.full_name, count(b.id)::int

--         into total_books
        from authors a
             left join books b on a.id = b.author_id
        where a.country = countrys
        group by a.id, a.full_name;
--     return coalesce(total_books, 0);
end;
$$;

alter function get_book_all_count(varchar) owner to postgres;

