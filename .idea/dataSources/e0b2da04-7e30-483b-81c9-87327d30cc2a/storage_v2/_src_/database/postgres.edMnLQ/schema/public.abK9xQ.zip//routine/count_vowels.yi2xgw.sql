create function count_vowels(unli character varying) returns integer
    language plpgsql
as
$$
declare
    v_char  varchar;
    v_count int := 0;
    i       int;
begin
    for i in 1..length(unli)
        loop
            v_char := lower(substr(unli, i, 1));
            if v_char in ('a', 'e', 'i', 'o', 'u') then
                v_count = v_count + 1;
            end if;

        end loop;
    return v_count;
end;
$$;

alter function count_vowels(varchar) owner to postgres;

