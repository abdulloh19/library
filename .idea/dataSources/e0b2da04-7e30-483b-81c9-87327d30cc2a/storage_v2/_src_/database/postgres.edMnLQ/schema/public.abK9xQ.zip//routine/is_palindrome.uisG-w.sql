create function is_palindrome(is_palindrom character varying) returns boolean
    language plpgsql
as
$$
begin
if is_palindrom = reverse(is_palindrom) then
    return true;
    else return false;
end if;
end;
$$;

alter function is_palindrome(varchar) owner to postgres;

