create function triple_example(INOUT trip numeric) returns numeric
    language plpgsql
as
$$
    begin
        trip := trip* 3;
        return ;
    end;
    $$;

alter function triple_example(inout numeric) owner to postgres;

