create function get_max_sold()
    returns TABLE(author_id integer, full_name character varying, sold integer)
    language plpgsql
as
$$

begin
    return query
    select a.id, a.full_name, b.sold
    from authors a
             join books b on a.id = b.author_id
    order by sold desc
    limit 1;

end;

$$;

alter function get_max_sold() owner to postgres;

