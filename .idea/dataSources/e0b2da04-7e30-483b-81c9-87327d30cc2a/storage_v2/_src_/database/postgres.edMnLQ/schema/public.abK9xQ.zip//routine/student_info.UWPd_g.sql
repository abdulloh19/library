create function student_info(OUT name character varying, OUT age integer) returns record
    language plpgsql
as
$$
begin
    name = 'Zubayr';
    age = 25;
end;
$$;

alter function student_info(out varchar, out integer) owner to postgres;

