create function count_expensive_books(min_price numeric) returns numeric
    language plpgsql
as
$$
DECLARE
    book_count numeric;
BEGIN
    SELECT COUNT(*)
    INTO book_count
    FROM books
    WHERE price > min_price;

    RETURN book_count;
END;
$$;

alter function count_expensive_books(numeric) owner to postgres;

